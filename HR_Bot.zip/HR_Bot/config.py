DATABASE_URL="postgres://swapnadeep:hrbot2020@database-2.cd0bzyysl9t2.ap-south-1.rds.amazonaws.com:5432/hrbot" 
SECRET_KEY="b'\xf9\xb3S;\xa5\xc3\xd7\xdd\xfaWi\x1b\xf5\r\xd0\xe9\xf3\x0c\xf0\x0c\x94s>\xb5|\xfdJ=4\x1d'"

EMAIL_ADDRESS = "HRBOT2020@gmail.com"
PASSWORD = "hrbot2020"